# Note, that CA_BOC getter seems not to be working
# from . import update_service_CA_BOC
from . import update_service_ECB
